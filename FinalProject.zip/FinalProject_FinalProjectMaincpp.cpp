#include <iostream>  
#include <string> 
#include <cstring> 
#include <cmath>   
#include <iomanip>  
#include <fstream> 
#include <cassert> 
#include <cstdlib>
#include <ctime>
#include <cctype>  
#include <algorithm>
#include <locale.h>
#include <stdio.h>
#include <functional>
#include <sstream>
#include <cstdlib>
#include <vector>
#include <array>
#include <iterator>
#include <tuple>
#include <sstream>
#include <map>
#include <unordered_map>
#include <list>

#include "mediator.h"
#include "airplaneparts.h"

using namespace std;

Mediator ::Mediator()
{
    MyEngine = new Engine(this);
    MyTurbine = new Turbine(this);
    
}

void Mediator::PartChanged(AirplanePart* part) // Chapter 9 Pointers
{
    if(part == MyEngine)
    {
        if(MyEngine->rpm == 0)
        {
            MyTurbine->Speed = 0;
            return;
        }
        if(MyEngine->revamount == 0)
        {
            return;
        }
    }
}

int main(int argc, char** argv) {
    string location1;
    string location2;
    
    Mediator *MyAirplane = new Mediator();
    MyAirplane->MyEngine->Start();
    
    cout << "--Flying Simulation Game--" <<endl;

    cout << "Enter your current location: " <<endl; //Chapter 10 Characters, C-Strings and the String Class  
    getline(cin,location1);
    
    cout << "Enter the place you want fly to : " <<endl;//Chapter 10 Characters, C-Strings and the String Class  
    getline(cin,location2);

    cout << "Engine Started!" <<endl;
    
       
    MyAirplane->MyTurbine->Accelerate(20);
    cout << "The Airplane is going : " << MyAirplane->MyTurbine->GetSpeed() << " MPH " <<endl;
    
    MyAirplane->MyTurbine->Accelerate(40);
    cout << "The Airplane is going : " << MyAirplane->MyTurbine->GetSpeed() << " MPH " <<endl;
    
    MyAirplane->MyTurbine->Accelerate(60);
    cout << "The Airplane is going : " << MyAirplane->MyTurbine->GetSpeed() << " MPH " <<endl;
    
    cout << "LIFTOFF!" << endl;
    
    cout << "This is your flight schedule for today: \n";
    cout << "From: " << (location1) << endl; // Chapter 10 Characters, C-Strings and the String Class  
    cout << "To: " << (location2) << endl; // Chapter 10 Characters, C-Strings and the String Class  

    cout<< "Airplane has landed at your destination!" << endl;
    
    
    MyAirplane->MyTurbine->Decelerate(10);
    cout << "The Airplane is going : " << MyAirplane->MyTurbine->GetSpeed() << " MPH " <<endl;
    
    MyAirplane->MyTurbine->Decelerate(50);
    cout << "The Airplane is going : " << MyAirplane->MyTurbine->GetSpeed() << " MPH " <<endl;
    
    MyAirplane->MyTurbine->Decelerate(30);
    cout << "The Airplane is going : " << MyAirplane->MyTurbine->GetSpeed() << " MPH " <<endl;
    
    MyAirplane->MyTurbine->Decelerate(30);
    cout << "The Airplane is going : " << MyAirplane->MyTurbine->GetSpeed() << " MPH " <<endl;
    
    MyAirplane->MyEngine->Stop();
    cout << "Thanks for flying." <<endl;

    return 0;
}