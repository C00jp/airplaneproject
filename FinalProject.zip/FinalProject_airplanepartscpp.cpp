#include "airplaneparts.h"

using namespace std;

void AirplanePart::Changed()
{
    mediator->PartChanged(this);
}

void Engine::Start()
{
    rpm = 1000;
    Changed();
}

void Engine::Throttle(int amount)
{
    revamount = amount;
    rpm += revamount;
    Changed();
}

void Engine::Stop()
{
    rpm = 0;
    revamount = 0;
    Changed();
}

void Turbine::Accelerate(int amount)
{
    Speed += amount;
    Changed();
}

void Turbine::Decelerate(int amount)
{
    Speed -= amount;
    Changed();
}