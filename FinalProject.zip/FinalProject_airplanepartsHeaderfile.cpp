#ifndef AIRPLANEPARTS_H
#define AIRPLANEPARTS_H

#include "mediator.h"

class AirplaneControls;

class AirplanePart //Introduction to Classes Chapter 13
{
protected:
    Mediator *mediator;
    AirplanePart(Mediator *med) : mediator(med) {}
    void Changed();
};

class Engine : public AirplanePart
{
protected:
    friend class Mediator; friend class AirplaneControls;
    int rpm;
    int revamount;

public:
    Engine(Mediator *med) : AirplanePart(med), rpm(0), revamount(0) {} //Chapter 9 Pointers
    void Start();
    void Throttle( int amount);
    void ReleasePedal(int amount);
    void Stop();
};

class Turbine : public AirplanePart
{
protected:
    friend class Mediator ; friend class AirplaneControls;
    int Speed;
    
public:
    Turbine(Mediator *med) : AirplanePart(med), Speed(0) {}
    int GetSpeed() {return Speed; }
    void Accelerate(int amount);
    void Decelerate(int amount);
    
};

#endif /* AIRPLANEPARTS_H */