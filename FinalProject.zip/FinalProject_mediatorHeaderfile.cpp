#ifndef MEDIATOR_H
#define MEDIATOR_H

class AirplanePart;
class Engine;
class Turbine;


class Mediator //Introduction to Classes Chapter 13
{
public:
    Engine *MyEngine;
    Turbine *MyTurbine;
    Mediator();
    void PartChanged(AirplanePart *part);
};

class AirplaneControls : public Mediator{ //Introduction to Classes Chapter 13
public:
    void StartAirplane();
    void StopAirplane();
    void Throttle( int amount);
    void PressBrake(int amount);
    int GetSpeed();
    AirplaneControls() : Mediator() {}
};
    



#endif /* MEDIATOR_H */

